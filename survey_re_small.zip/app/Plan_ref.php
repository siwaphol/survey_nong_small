<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Plan_ref extends Model
{

    //
}
