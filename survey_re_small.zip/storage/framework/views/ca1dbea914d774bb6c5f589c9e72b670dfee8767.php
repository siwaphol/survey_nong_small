<script>
    <?php if(session()->has('flash_notification.message')): ?>
        new PNotify({
        title: '<?php echo session('flash_notification.message'); ?>',
        type: 'success'
    });
    <?php endif; ?>
</script>