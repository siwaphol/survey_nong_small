<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fuel_user_for_product_ratio extends Model
{
    //
}
