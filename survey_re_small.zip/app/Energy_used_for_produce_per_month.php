<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Energy_used_for_produce_per_month extends Model
{

    //
}
