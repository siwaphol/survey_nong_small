<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produce_process extends Model
{
	
    //
}
