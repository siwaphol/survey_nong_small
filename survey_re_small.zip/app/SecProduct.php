<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SecProduct extends Model
{
    //
}
